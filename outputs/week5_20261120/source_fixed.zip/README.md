# Khi hành động trì hoãn là một bộ phân lớp

**Chow's Rule Fails When the Abstention Is a Classifier: Exact Conditions for Interval-Optimality of Three-Action Risk Policies, and the Regret of Two-Threshold Designs**


## Câu hỏi nghiên cứu

Trên Credit Card Fraud (tầng 1 hồi quy logistic đã hiệu chuẩn, tầng 2 gradient boosting, chi phí bỏ sót / chặn nhầm / leo thang = 100 / 1 / 0,2), chi phí kiểm thử trên mỗi giao dịch của **chính sách hai ngưỡng tốt nhất** cao hơn **chính sách ba hành động tối ưu theo từng khoảng điểm** bao nhiêu phần trăm, trung bình qua 20 lần chia dữ liệu (kèm khoảng tin cậy 95%)?

## Chạy nhanh (smoke test)

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
make smoke            # hoặc: python scripts/smoke_test.py
make test             # 124 tests
```

Kết quả mong đợi: dòng cuối là `SMOKE TEST PASSED`, mã thoát 0, và file `outputs/smoke_results.json`.

Smoke test chạy toàn bộ chuỗi *sinh dữ liệu → chia 60/20/20 → hiệu chuẩn Platt → chia khoảng → bảng chi phí → hai chính sách → chi phí và regret trên test* cho hai kịch bản tổng hợp đã biết trước đáp án:

| Kịch bản | Sai số tầng 2 | Điều phải thấy |
|---|---|---|
| `constant` | không đổi theo điểm | regret xấp xỉ 0, chính sách theo khoảng có dạng hai ngưỡng |
| `blind_spot` | tầng 2 "mù" trong một cửa sổ điểm | chính sách tối ưu bị đứt (leo thang → chặn → leo thang → chặn), regret > 0, ROC tốn hơn quét lưới rõ rệt |

Ngoài ra `perfect` (tầng 2 không sai, đúng trường hợp Chow: ngưỡng 0,002 và 0,8) dùng trong unit test. `synthetic.analytic_costs` tính đáp án giải tích bằng tích phân: ở `blind_spot`, hai ngưỡng tốt nhất tốn hơn chính sách tối ưu 9,07% và ROC tốn hơn 62,79%.

> Smoke test chỉ chứng minh **code nối đúng**, không phải kết quả khoa học. Dữ liệu tổng hợp do chúng tôi thiết kế để hiện tượng xuất hiện.

## Chạy trên dữ liệu thật
Tải dữ liệu Credit Card Fraud Detection OpenML ID 1597
```bash
python -c "from sklearn.datasets import fetch_openml;
df = fetch_openml(data_id=1597, as_frame=True).frame;
df.to_csv('data/creditcard.csv', index=False);
```
Chạy
```bash
python scripts/run_creditcard.py --csv data/creditcard.csv --n-splits 20 --K 10 --method logit
# hoặc: python scripts/run_creditcard.py --openml --n-splits 1
```

Kiểm tra sau khi tải: 284.807 dòng, 492 gian lận. Script giữ mọi dòng và chia theo nhóm đặc trưng float64; nhóm trùng không xuyên train/val/test hoặc các fold OOF.

## Phương pháp tóm tắt

- **Ba hành động:** cho qua / leo thang / chặn. Chi phí: bỏ sót gian lận 100, chặn nhầm 1, leo thang 0,2 cộng lỗi của tầng 2 (`src/threeaction/costs.py`).
- **Tầng 1** cho điểm thô, **hiệu chuẩn Platt** học trên dự đoán OOF-train, CV giữ nhóm đặc trưng thành điểm `s`. **Tầng 2** cho quyết định cuối với ngưỡng `t2` cố định một lần từ dự đoán ngoài mẫu trên train.
- **Chia khoảng:** biên khoảng tính từ **train**, dùng nguyên cho val/test (`bins.py`: `quantile`, `logit`, `fraud_quantile`, kèm gộp khoảng để mỗi khoảng đủ gian lận).
- **Baseline ROC-optimal** (`roc_baseline.py`): giả định chi phí leo thang là hằng số theo lớp (a⁺ cho gian lận, a⁻ cho giao dịch hợp lệ, ước lượng từ **train**), đường ROC lấy từ **val**. Đại diện cho thiết kế hai ngưỡng truyền thống. Khác quét lưới ở chỗ nó tối ưu một *mô hình* chi phí (hằng số), còn quét lưới (`exact_two_threshold`, O(n)) tối ưu chi phí thật. Hai cách trùng nhau khi chi phí leo thang đúng là hằng số.
- **Hai chính sách chọn từ cùng một bảng chi phí trên val** (`policies.py`): theo khoảng (mỗi khoảng chọn hành động rẻ nhất) và hai ngưỡng (cho qua → leo thang → chặn liền nhau, ngưỡng đặt trên biên khoảng nên là tập con của chính sách theo khoảng).
- **Đánh giá chỉ trên test:** chi phí trung bình mỗi giao dịch, regret tuyệt đối và tương đối, khoảng tin cậy bootstrap theo cặp.

## Giả định và hạn chế
- Regret đo ở đây là so với chính sách tối ưu trong lớp "hàm của điểm tầng 1 chia K khoảng", ước lượng từ dữ liệu. **Không phải regret Bayes thật.**
- Tập kiểm định chỉ có khoảng 98 gian lận: chính sách theo khoảng có thể khớp nhiễu (đã quan sát trong smoke test, kịch bản `constant`, seed 3). Vì vậy K nhỏ, có gộp khoảng, và báo cáo kèm khoảng tin cậy; regret âm hoặc gần 0 là kết quả hợp lệ.
- Chia ngẫu nhiên, không xét trôi dữ liệu theo thời gian. 20 lần chia dùng chung dữ liệu nên không độc lập.
- Chi phí 100/1/0,2 là giả định đã khóa; không quét thêm độ nhạy trong tuần 5.
- Tập đặc trưng tầng 1 giữ cố định: Amount, V1–V10 (không Time); tầng 2: Amount, V1–V28. Không tìm subset mới trong tuần 5.

## Cấu trúc thư mục

```
src/threeaction/   costs, bins, calibrate, tier2, policies, roc_baseline, pipeline, synthetic
scripts/           smoke_test.py (không cần mạng), run_creditcard.py (dữ liệu thật)
tests/             test_core.py, test_roc.py (124 tests; unittest, chạy được với pytest)
data/  outputs/    dữ liệu thô và kết quả (không commit)
```


## Tài liệu tham khảo

- Dal Pozzolo et al., Credit Card Fraud Detection dataset
- Narasimhan et al., NeurIPS 2022 
- Chow, C. K. (1970), *On optimum recognition error and reject tradeoff* 


## Tuần 5: protocol sau sửa lỗi

Giữ dòng trùng, chia 60/20/20 theo nhóm (tỷ lệ dòng xấp xỉ); nhóm dùng feature float64, không nhãn. Nhãn any-positive chỉ dùng phân tầng nhóm. Scaler, hai mô hình và Platt chỉ học train/OOF-train. Archive cũ đã khử trùng không dùng với protocol này.

```bash
python scripts/freeze_week5.py --csv data/creditcard_openml_1597.csv
python scripts/run_creditcard.py --csv data/creditcard_openml_1597.csv --n-splits 20 --K 10 --method logit --min-pos 5 --n-boot 500 --splits data/splits_week5_grouped.npz --out outputs/week5_logit.json
python scripts/run_creditcard.py --csv data/creditcard_openml_1597.csv --n-splits 20 --K 10 --method fraud_quantile --min-pos 5 --n-boot 500 --splits data/splits_week5_grouped.npz --out outputs/week5_fraud_quantile.json
```

Artifact mới chứa hash mã nguồn, CSV, archive và phiên bản môi trường. Các artifact cũ là exploratory; không trộn hai protocol. Báo cáo thực thi nằm trong `outputs/week5_20261120/BAO_CAO_TUAN_5.md`.
