#!/usr/bin/env python
"""Real-data experiment on Credit Card Fraud (OpenML id 1597 or a local CSV).

  python scripts/run_creditcard.py --csv data/creditcard.csv --n-splits 20
  python scripts/run_creditcard.py --openml --n-splits 1        # needs internet

Per split: stratified 60/20/20 -> tier 1 (logistic regression on a feature subset)
-> Platt calibration on OOF TRAIN -> tier 2 (gradient boosting, all features) ->
t2 from out-of-fold TRAIN predictions -> bins from TRAIN -> policies chosen on
VAL -> cost and paired-bootstrap regret on TEST.

The tier-1 feature subset is held fixed for the week-5 scope lock.
"""
import argparse
import json
import os
import sys
import time
import hashlib
import platform
import subprocess
from pathlib import Path
import sklearn

if sys.stdout.encoding != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))

from threeaction.calibrate import PlattCalibrator, ece, reliability_table   # noqa: E402
from threeaction.pipeline import run_policies                                # noqa: E402
from threeaction.data_split import feature_groups, grouped_split, validate_split, group_oof_splits
from threeaction.tier2 import choose_t2                                      # noqa: E402

ALL_FEATURES = [ "Amount"] + [f"V{i}" for i in range(1, 29)]
TIER1_FEATURES = [ "Amount"] + [f"V{i}" for i in range(1, 11)]  # frozen existing feature set; no subset search


def load(csv=None, openml=False, dedupe=True):
    if csv:
        df = pd.read_csv(csv)
    elif openml:
        from sklearn.datasets import fetch_openml
        df = fetch_openml(data_id=1597, as_frame=True).frame
    else:
        raise SystemExit("give --csv PATH or --openml")
    df = df.rename(columns={c: c.strip() for c in df.columns})
    label = "Class" if "Class" in df.columns else df.columns[-1]
    df[label] = pd.to_numeric(df[label], errors="raise")
    if not np.isin(df[label], [0, 1]).all():
        raise ValueError("Labels must be binary")
    df[label] = df[label].astype(int)
    missing = [c for c in ALL_FEATURES if c not in df.columns]
    if missing:
        raise SystemExit(f"missing columns: {missing}")
    n0 = len(df)
    # Keep duplicate rows; feature groups, never labels, constrain splitting.
    df[ALL_FEATURES] = df[ALL_FEATURES].astype(np.float64)
    feature_groups(df[ALL_FEATURES])
    print(f"rows: {n0} -> {len(df)} with duplicate rows retained; frauds: {int(df[label].sum())} "
          f"({100 * df[label].mean():.3f}%)")
    return df[ALL_FEATURES].reset_index(drop=True), df[label].to_numpy()


def one_split(X, y, seed, K, method, min_pos, n_boot, splits_archive=None):
    groups = feature_groups(X[ALL_FEATURES])
    if splits_archive is not None:
        required = [f"{part}_{seed}" for part in ("train", "val", "test")]
        if any(k not in splits_archive for k in required):
            raise ValueError(f"Incomplete frozen split for seed {seed}")
        tr, va, te = [splits_archive[k] for k in required]
    else:
        tr, va, te = grouped_split(y, groups, seed)
    validate_split(y, groups, tr, va, te)

    # tier 1 + Platt: scaler/model folds and calibration learn only from TRAIN
    lr = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000))
    p1_oof = cross_val_predict(lr, X.iloc[tr][TIER1_FEATURES], y[tr],
                               cv=group_oof_splits(y[tr], groups[tr], seed),
                               method="predict_proba")[:, 1]
    lr.fit(X.iloc[tr][TIER1_FEATURES], y[tr])
    p_raw = lr.predict_proba(X[TIER1_FEATURES])[:, 1]
    p_raw[tr] = p1_oof
    cal = PlattCalibrator().fit(p1_oof, y[tr])
    s = cal.transform(p_raw)

    # tier 2 and its fixed threshold t2 (out-of-fold on TRAIN)
    gb = HistGradientBoostingClassifier(random_state=seed)
    p2_oof = cross_val_predict(gb, X.iloc[tr][ALL_FEATURES], y[tr],
                               cv=group_oof_splits(y[tr], groups[tr], seed),
                               method="predict_proba")[:, 1]
    t2, _ = choose_t2(p2_oof, y[tr])
    gb.fit(X.iloc[tr][ALL_FEATURES], y[tr])
    p2 = gb.predict_proba(X[ALL_FEATURES])[:, 1]
    block2 = (p2 >= t2).astype(int)
    block2[tr] = (p2_oof >= t2).astype(int)       # train rows use out-of-fold decisions

    parts = [{"s": s[i], "y": y[i], "tier2_block": block2[i]} for i in (tr, va, te)]
    res = run_policies(*parts, K=K, method=method, min_pos=min_pos,
                       n_boot=n_boot, seed=seed)
    res.update(t2=float(t2), ece_test=float(ece(s[te], y[te])),
               reliability=reliability_table(s[te], y[te], 10))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv"); ap.add_argument("--openml", action="store_true")
    ap.add_argument("--n-splits", type=int, default=1)
    ap.add_argument("--K", type=int, default=10)
    ap.add_argument("--method", default="logit", choices=["quantile", "logit", "fraud_quantile"])
    ap.add_argument("--min-pos", type=int, default=5)
    ap.add_argument("--n-boot", type=int, default=500)
    ap.add_argument("--no-dedupe", action="store_true", help="Legacy flag; duplicate rows are always retained")
    ap.add_argument("--splits", default=os.path.join(ROOT, "data", "splits_week5_grouped.npz"),
                    help="Path to frozen splits npz (optional)")
    ap.add_argument("--out", default=os.path.join(ROOT, "outputs", "creditcard_week5_results.json"))
    a = ap.parse_args()

    splits_archive = None
    if a.splits and os.path.exists(a.splits):
        splits_archive = np.load(a.splits)
        print(f"Loaded frozen splits from {a.splits}")

    X, y = load(a.csv, a.openml, dedupe=not a.no_dedupe)
    rows = []
    t0 = time.time()
    for seed in range(a.n_splits):
        r = one_split(X, y, seed, a.K, a.method, a.min_pos, a.n_boot, splits_archive=splits_archive)
        rg = r["test_regret"]
        print(f"split {seed:2d}: K_eff={r['K_effective']:2d} t2={r['t2']:.4f} "
              f"test cost two={r['test_cost_two']:.5f} bin={r['test_cost_bin']:.5f} "
              f"regret={rg['abs']:+.5f} ({100 * rg['rel']:+.2f}%) ECE={r['ece_test']:.5f}")
        o, ex = r["roc"], r["exact_two_threshold"]
        print(f"          ROC: a+={o['a_plus']:.2f} a-={o['a_minus']:.3f} t=({o['t_low']:.5f},"
              f" {o['t_high']:.4f}) test cost={o['test_cost']:.5f} "
              f"| exact two-thr test cost={ex['test_cost']:.5f}")
        rows.append({"roc_a_plus": o["a_plus"], "roc_a_minus": o["a_minus"],
                     "roc_t_low": o["t_low"], "roc_t_high": o["t_high"],
                     "roc_test_cost": o["test_cost"],
                     "roc_snapped_test_cost": o["snapped_test_cost"],
                     "roc_regret_vs_per_bin_rel": o["regret_vs_per_bin"]["rel"],
                     "exact_two_threshold_test_cost": ex["test_cost"],
                     "seed": seed, "K_eff": r["K_effective"], "t2": r["t2"],
                     "t_low": r["t_low"], "t_high": r["t_high"],
                     "test_cost_two": r["test_cost_two"], "test_cost_bin": r["test_cost_bin"],
                     "regret_abs": rg["abs"], "regret_rel": rg["rel"],
                     "regret_rel_ci": list(rg["rel_ci"]),
                     "per_bin_two_threshold_shape": r["per_bin_is_two_threshold_shape"],
                     "ece_test": r["ece_test"]})
    ct = np.mean([r["test_cost_two"] for r in rows]); cb = np.mean([r["test_cost_bin"] for r in rows])
    cr = np.mean([r["roc_test_cost"] for r in rows])
    agg = {"mean_cost_roc": cr,
           "mean_rel_regret_roc": (cr - cb) / cb if cb > 0 else None,
           "mean_cost_two": ct, "mean_cost_bin": cb, "mean_abs_regret": ct - cb,
           "mean_rel_regret": (ct - cb) / cb if cb > 0 else None,
           "std_abs_regret_across_splits": float(np.std([r["regret_abs"] for r in rows]))}
    print("\nAGGREGATE over", a.n_splits, "split(s):", json.dumps(agg, indent=2))
    print(f"elapsed {time.time() - t0:.1f}s")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    def checksum(path):
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    root = Path(ROOT)
    provenance = {
        "protocol": "feature-group splits; retained rows; group-OOF train calibration",
        "command": sys.argv,
        "environment": {"python": platform.python_version(), "numpy": np.__version__,
                        "pandas": pd.__version__, "sklearn": sklearn.__version__},
        "source_hashes": {str(p.relative_to(root)): checksum(p)
                          for folder in ("src", "scripts")
                          for p in (root / folder).rglob("*.py")},
        "csv_sha256": checksum(a.csv) if a.csv else None,
        "splits_sha256": checksum(a.splits) if a.splits and Path(a.splits).exists() else None,
        "tier1_features": TIER1_FEATURES, "tier2_features": ALL_FEATURES,
        "costs": {"miss": 100, "false_block": 1, "escalate": .2},
    }
    if (root / ".git").exists():
        provenance["git_head"] = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        provenance["git_status"] = subprocess.check_output(["git", "status", "--short"], cwd=ROOT, text=True)
    with open(a.out, "w") as f:
        json.dump({"args": vars(a), "provenance": provenance, "splits": rows, "aggregate": agg}, f, indent=2)


if __name__ == "__main__":
    main()
